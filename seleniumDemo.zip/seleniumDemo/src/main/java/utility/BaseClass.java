package utility;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import pageFactoryRepo.HomePagePFRepo;
import pageFactoryRepo.LoginPFRepo;

public class BaseClass {
    public static WebDriver baseDriver;
//    public LoginPFRepo loginPFRepo;
//    public HomePagePFRepo homePagePFRepo;

    @BeforeSuite
    @Parameters("browserName")
    public void setupSuite(String browser){
        if (browser.equals("Chrome")){
            WebDriverManager.chromedriver().setup();
            baseDriver = new ChromeDriver();
        } else if (browser.equals("FireFox")) {
            WebDriverManager.firefoxdriver().setup();
            baseDriver = new FirefoxDriver();
        }
        else {
            WebDriverManager.edgedriver().setup();
            baseDriver = new EdgeDriver();
        }

        baseDriver.manage().window().maximize();
        PageFactory.initElements(baseDriver,LoginPFRepo.class);
        PageFactory.initElements(baseDriver, HomePagePFRepo.class);
    }
    @AfterSuite
    public void closeSuite(){
        baseDriver.quit();
    }
    public static void waitForElementVisible(WebElement element){
        WebDriverWait wait = new WebDriverWait(baseDriver,10);
        wait.until(ExpectedConditions.visibilityOf(element));
    }
    public static void clickOnElement(WebElement element){
        element.click();

    }
    public static void enterDataInElement(WebElement element,String data){
        element.sendKeys(data);
    }
}
