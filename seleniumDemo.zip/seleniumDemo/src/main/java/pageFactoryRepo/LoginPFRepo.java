package pageFactoryRepo;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utility.BaseClass;

import static utility.BaseClass.*;

public class LoginPFRepo{
    public WebDriver thisClassDriver;

    @FindBy(id = "user-name")
    public static WebElement userNameInput;
    @FindBy(id = "password")
    public static WebElement passwordInput;
    @FindBy(id = "login-button")
    public static WebElement loginButton;

    public LoginPFRepo(WebDriver tempDriver){
        thisClassDriver = tempDriver;
    }

    public static void enterUserName(String username){
        enterDataInElement(userNameInput,username);
//        userNameInput.sendKeys(username);
    }
    public static void enterPassword(String password){
        waitForElementVisible(passwordInput);
        enterDataInElement(passwordInput,password);
//        passwordInput.sendKeys(password);
    }
    public static void clickLoginButton(){
        clickOnElement(loginButton);
//        loginButton.click();
    }
    public static void fillLoginDetails(String username,String password){
        enterUserName(username);
        enterPassword(password);
        clickLoginButton();
    }
}
