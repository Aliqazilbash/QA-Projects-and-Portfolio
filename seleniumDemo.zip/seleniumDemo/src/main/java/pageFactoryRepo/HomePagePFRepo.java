package pageFactoryRepo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utility.BaseClass;

import static utility.BaseClass.*;


public class HomePagePFRepo{
    public WebDriver thisClassDriver;
    public WebDriverWait waitForThisClass;

    @FindBy(className = "app_logo")
    public static WebElement appHeader;
    @FindBy(id = "react-burger-menu-btn")
    public static WebElement menuButton;
    @FindBy(id = "logout_sidebar_link")
    public static WebElement logoutButton;

    public HomePagePFRepo(WebDriver tempDriver){
        thisClassDriver = tempDriver;
        waitForThisClass = new WebDriverWait(thisClassDriver,10);
    }
    public static void waitForHeader(){
        waitForElementVisible(appHeader);
    }
    public static void clickMenuButton(){
        waitForElementVisible(menuButton);
        clickOnElement(menuButton);
    }
    public static void clickLogoutButton(){
        waitForElementVisible(logoutButton);
        clickOnElement(logoutButton);
    }
    public static void logoutUser(){
        waitForHeader();
        clickMenuButton();
        clickLogoutButton();
    }
}
