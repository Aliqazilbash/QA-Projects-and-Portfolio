package TestCases;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageFactoryRepo.HomePagePFRepo;
import pageFactoryRepo.LoginPFRepo;

public class abc123 {
    public WebDriver driver;
    public LoginPFRepo loginPFRepo;
    public HomePagePFRepo homePagePFRepo;
    @BeforeClass
    public void setupClass(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        loginPFRepo = PageFactory.initElements(driver,LoginPFRepo.class);
        homePagePFRepo = PageFactory.initElements(driver, HomePagePFRepo.class);
    }
    @Test
    public void loginTestCase001(){
        driver.get("https://www.saucedemo.com/");
        loginPFRepo.fillLoginDetails("standard_user","secret_sauce");
        homePagePFRepo.logoutUser();
    }
    @Test
    public void loginTestCase002(){
        driver.get("https://www.google.com/");

    }
    @Test
    public void loginTestCase003(){
        driver.get("http://hrms.exdnow.com:8080/hrms-exd/hrms/index.php");
    }
    @Test
    public void loginTestCase004(){
        driver.get("https://www.exdnow.com/");

    }
    @AfterClass
    public void destroyDriver(){
        driver.quit();
    }
}
