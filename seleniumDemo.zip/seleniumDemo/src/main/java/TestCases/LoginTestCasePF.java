package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;
import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;
import pageFactoryRepo.HomePagePFRepo;
import pageFactoryRepo.LoginPFRepo;
import utility.BaseClass;

import java.lang.reflect.Method;

import static ExtentReportPackage.ExtentTestManager.startTest;
import static pageFactoryRepo.HomePagePFRepo.*;
import static pageFactoryRepo.LoginPFRepo.*;

public class LoginTestCasePF extends BaseClass {

    public Assertion hardAssertion;
    public Assertion softAssertion;
    @BeforeClass
    public void setupClass(){

        hardAssertion = new Assertion();
        softAssertion = new SoftAssert();
    }

    @Test(priority = 3,invocationCount = 3)
    @Parameters({"userName","password"})
    public void loginTestCase001(String username,String password,Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.saucedemo.com/");
        fillLoginDetails(username, password);
        logoutUser();
    }
    @Test(priority = 4)
    public void loginTestCase002(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.google.com/");

    }
    @Test(priority = 1)
    public void loginTestCase003(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("http://hrms.exdnow.com:8080/hrms-exd/hrms/index.php");
    }

    @Test(priority = 2)
    public void loginTestCase004(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.exdnow.com/");
    }
    @Test(priority = 5)
    public void loginTestCase005(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.saucedemo.com/");
        String message = baseDriver.findElement(By.className("login_logo")).getText();
        softAssertion.assertEquals(message,"Swaggy");
    }
    @Test(priority = 6)
    public void loginTestCase006(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.saucedemo.com/");
        String message = baseDriver.findElement(By.className("login_logo")).getText();
        hardAssertion.assertEquals(message,"abcd");
    }
    @Test(priority = 7)
    public void loginTestCase007(Method method){
        startTest(method.getName(),"Description of test Case");
        baseDriver.get("https://www.exdnow.com/");
    }
    @AfterClass
    public void destroybaseDriver(){
//        baseDriver.quit();
    }
}
